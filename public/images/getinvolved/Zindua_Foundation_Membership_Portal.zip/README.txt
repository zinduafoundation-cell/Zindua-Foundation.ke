ZINDUA FOUNDATION MEMBERSHIP PORTAL
====================================

What this package does
----------------------
Creates a private Google Drive folder, a Google Sheet membership register,
and a branded member-registration web app. Members can submit personal
details and upload National ID front/back and a signature. Each submission
receives an automatically generated ZF-001, ZF-002... member ID.

IMPORTANT
---------
I cannot directly create the live Google Drive/Apps Script link inside your
Google account from this chat because that requires authorization to your
Google account. This package is ready for you to deploy in YOUR account.

SETUP (PHONE OR COMPUTER)
------------------------
1. Open https://script.google.com/
2. Create a New project.
3. Replace Code.gs with the contents of Code.gs from this package.
4. Add a new HTML file named exactly: Index
5. Paste the contents of Index.html into that file.
6. Save.
7. Run the function `setup` once.
8. Google will ask for permissions. Review and allow access to Forms/Drive/
   Sheets as requested by the script.
9. Open Executions/Logs and confirm the spreadsheet was created.
10. Click Deploy > New deployment.
11. Select Web app.
12. Execute as: Me (your Google account).
13. Who has access: choose the narrowest option that works for your members.
    If you use "Anyone", do NOT post the link publicly; share it only with
    intended members.
14. Deploy and copy the Web app URL.
15. Send that one URL to every founder/member. Each person submits their own
    details.

ADMIN
-----
The generated Google Sheet has:
- Members: detailed register
- Admin: counts and links
- Lists: hidden reference lists

The generated Drive folder contains:
- One subfolder per member ID
- National ID front
- National ID back
- Signature
- Application record

The app sets new applications to:
- Verification Status: Pending
- Membership Status: Pending

Only an authorized Foundation official should change these to Verified/Active.

SECURITY
--------
National IDs and signatures are sensitive. Keep the spreadsheet and Drive
folder private. Do not put the folder on "Anyone with the link". Restrict
admin access to the founders/authorized officers. If the Foundation is
operating in Kenya, establish an appropriate privacy notice, retention
period and lawful basis before collecting/retaining these documents.

The web app uses Google Apps Script HTML Service. Google documents that an
HTML form passed to google.script.run can carry file inputs as Blob objects,
which can then be saved to Drive.
