/**
 * ZINDUA FOUNDATION - MEMBERSHIP PORTAL
 * Setup + secure member registration web app.
 *
 * IMPORTANT:
 * 1) Run setup() once.
 * 2) Deploy as Web app: Execute as "Me"; access should be limited to the
 *    intended members where your Google account/domain allows it.
 * 3) Keep the generated spreadsheet and Drive folder private.
 */

const APP_NAME = 'Zindua Foundation';
const SHEET_NAME = 'Members';
const FOLDER_NAME = 'Zindua Foundation - Member Documents';

const HEADERS = [
  'Timestamp','Member ID','Full Legal Name','Preferred Name','Phone Number',
  'Email Address','Date of Birth','County','Membership Category','Position / Role',
  'Date Joined','National ID Number','National ID Front','National ID Back',
  'Signature','Skills / Area of Interest','Verification Status','Membership Status',
  'Verified By','Verification Date','Remarks'
];

const COUNTIES = [
  'Baringo','Bomet','Bungoma','Busia','Elgeyo-Marakwet','Embu','Garissa',
  'Homa Bay','Isiolo','Kajiado','Kakamega','Kericho','Kiambu','Kilifi',
  'Kirinyaga','Kisii','Kisumu','Kitui','Kwale','Laikipia','Lamu','Machakos',
  'Makueni','Mandera','Marsabit','Meru','Migori','Mombasa',"Murang'a",'Nairobi',
  'Nakuru','Nandi','Narok','Nyamira','Nyandarua','Nyeri','Samburu','Siaya',
  'Taita-Taveta','Tana River','Tharaka-Nithi','Trans Nzoia','Turkana',
  'Uasin Gishu','Vihiga','Wajir','West Pokot'
];

const CATEGORIES = ['New Member','Volunteer','Founding Member (by invitation)','Leadership Member (by invitation)'];
const ROLES = [
  'Ordinary Member','Volunteer','Committee Member',
  'Chairperson / Founder','Vice Chairperson / Co-Founder',
  'Secretary / Co-Founder','Treasurer / Co-Founder',
  'Programs & Community Director / Co-Founder'
];

function setup() {
  const props = PropertiesService.getScriptProperties();

  let ss;
  const existingId = props.getProperty('SHEET_ID');
  if (existingId) {
    try { ss = SpreadsheetApp.openById(existingId); } catch (e) {}
  }
  if (!ss) {
    ss = SpreadsheetApp.create('Zindua Foundation - Official Membership Register');
    props.setProperty('SHEET_ID', ss.getId());
  }

  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  sh.clear();
  sh.getRange(1,1,1,HEADERS.length).setValues([HEADERS]);
  sh.setFrozenRows(1);
  sh.getRange(1,1,1,HEADERS.length)
    .setFontWeight('bold').setBackground('#111111').setFontColor('#ffffff');
  sh.setColumnWidths(1, HEADERS.length, 150);
  sh.setColumnWidth(3, 220);
  sh.setColumnWidth(12, 150);
  sh.setColumnWidth(13, 220);
  sh.setColumnWidth(14, 220);
  sh.setColumnWidth(15, 220);
  sh.getRange('Q:Q').setBackground('#FFF2CC');
  sh.getRange('R:R').setBackground('#EAF5EE');

  // Admin sheet
  let admin = ss.getSheetByName('Admin');
  if (!admin) admin = ss.insertSheet('Admin');
  admin.clear();
  admin.getRange('A1:B9').setValues([
    ['ZINDUA FOUNDATION','ADMIN SETTINGS'],
    ['Spreadsheet URL', ss.getUrl()],
    ['Member documents folder',''],
    ['Total registered','=COUNTA(Members!C2:C)'],
    ['Pending verification','=COUNTIF(Members!Q2:Q,"Pending")'],
    ['Verified','=COUNTIF(Members!Q2:Q,"Verified")'],
    ['Active','=COUNTIF(Members!R2:R,"Active")'],
    ['Pending membership','=COUNTIF(Members!R2:R,"Pending")'],
    ['Note','Keep this sheet and the spreadsheet restricted to authorized Foundation officials.']
  ]);
  admin.getRange('A1:B1').setFontWeight('bold').setBackground('#111111').setFontColor('#ffffff');
  admin.getRange('A2:A9').setFontWeight('bold');
  admin.setColumnWidth(1, 230);
  admin.setColumnWidth(2, 650);

  let folder;
  const folderId = props.getProperty('FOLDER_ID');
  if (folderId) {
    try { folder = DriveApp.getFolderById(folderId); } catch (e) {}
  }
  if (!folder) {
    folder = DriveApp.createFolder(FOLDER_NAME);
    props.setProperty('FOLDER_ID', folder.getId());
  }
  admin.getRange('B3').setValue(folder.getUrl());

  // Keep a copy of the system workbook in the same folder.
  const file = DriveApp.getFileById(ss.getId());
  try { folder.addFile(file); } catch(e) {}

  // Optional: make a hidden setup sheet with lists.
  let lists = ss.getSheetByName('Lists');
  if (!lists) lists = ss.insertSheet('Lists');
  lists.clear();
  lists.getRange(1,1,1,3).setValues([['County','Membership Category','Role']]);
  const max = Math.max(COUNTIES.length,CATEGORIES.length,ROLES.length);
  const rows = [];
  for (let i=0;i<max;i++) rows.push([COUNTIES[i]||'', CATEGORIES[i]||'', ROLES[i]||'']);
  lists.getRange(2,1,rows.length,3).setValues(rows);
  lists.hideSheet();

  SpreadsheetApp.flush();

  Logger.log('Spreadsheet: ' + ss.getUrl());
  Logger.log('Documents folder: ' + folder.getUrl());
  Logger.log('Deploy this project as a Web app after saving.');
}

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Zindua Foundation - Membership Registration')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getFormData() {
  return {
    counties: COUNTIES,
    categories: CATEGORIES,
    roles: ROLES
  };
}

function submitMember(form) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  try {
    validateForm_(form);

    const props = PropertiesService.getScriptProperties();
    const ss = SpreadsheetApp.openById(props.getProperty('SHEET_ID'));
    const sh = ss.getSheetByName(SHEET_NAME);
    const folder = DriveApp.getFolderById(props.getProperty('FOLDER_ID'));

    const memberId = nextMemberId_(sh);
    const memberFolder = folder.createFolder(memberId + ' - ' + safeName_(form.fullName));

    const idFront = saveBlob_(form.idFront, memberFolder, memberId + ' - National ID Front');
    const idBack = saveBlob_(form.idBack, memberFolder, memberId + ' - National ID Back');
    const signature = saveBlob_(form.signature, memberFolder, memberId + ' - Signature');

    const now = new Date();
    const row = [
      now, memberId, form.fullName.trim(), (form.preferredName||'').trim(),
      form.phone.trim(), form.email.trim(), form.dob, form.county,
      form.category, form.role, form.dateJoined, form.nationalId.trim(),
      idFront.url, idBack.url, signature.url, (form.skills||'').trim(),
      'Pending', 'Pending', '', '', ''
    ];
    sh.appendRow(row);

    // Create a member record file in the member folder.
    const record = [
      'ZINDUA FOUNDATION',
      'HOPE • EDUCATE • EMPOWER',
      '',
      'OFFICIAL MEMBERSHIP APPLICATION',
      'Member ID: ' + memberId,
      'Full Legal Name: ' + form.fullName,
      'Membership Category: ' + form.category,
      'Position / Role: ' + form.role,
      'Application Date: ' + now.toISOString(),
      'Verification Status: Pending',
      'Membership Status: Pending',
      '',
      'This record is an internal administrative document. It is not a government identity document.'
    ].join('\n');
    memberFolder.createFile(memberId + ' - Application Record.txt', record, MimeType.PLAIN_TEXT);

    return {
      success: true,
      memberId: memberId,
      message: 'Application received successfully. Your Zindua Foundation Member ID is ' + memberId + '.'
    };
  } finally {
    lock.releaseLock();
  }
}

function validateForm_(f) {
  const required = ['fullName','phone','email','dob','county','category','role','dateJoined','nationalId'];
  required.forEach(k => { if (!f[k] || String(f[k]).trim() === '') throw new Error('Please complete all required fields.'); });
  if (!f.idFront || !f.idBack || !f.signature) throw new Error('Please upload the National ID front, National ID back and signature.');
  if (!COUNTIES.includes(f.county)) throw new Error('Invalid county selected.');
  if (!CATEGORIES.includes(f.category)) throw new Error('Invalid membership category.');
  if (!ROLES.includes(f.role)) throw new Error('Invalid role selected.');
  if (String(f.nationalId).length < 5) throw new Error('Please enter a valid National ID number.');
  if (f.idFront.getBytes().length > 5*1024*1024 || f.idBack.getBytes().length > 5*1024*1024 || f.signature.getBytes().length > 5*1024*1024) {
    throw new Error('Each uploaded file must be 5 MB or smaller.');
  }
  const allowed = ['image/jpeg','image/png','application/pdf'];
  [f.idFront,f.idBack,f.signature].forEach(b => {
    if (!allowed.includes(b.getContentType())) throw new Error('Uploads must be JPG, PNG or PDF files.');
  });
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email.trim())) throw new Error('Please enter a valid email address.');
}

function saveBlob_(blob, folder, baseName) {
  if (!blob || !blob.getBytes().length) throw new Error('Missing upload.');
  const ext = extension_(blob.getName(), blob.getContentType());
  const file = folder.createFile(blob).setName(baseName + ext);
  return { url: file.getUrl(), id: file.getId() };
}

function extension_(name, mime) {
  const m = {
    'image/jpeg': '.jpg',
    'image/png': '.png',
    'application/pdf': '.pdf'
  };
  const match = String(name||'').match(/\.[A-Za-z0-9]+$/);
  return match ? match[0].toLowerCase() : (m[mime] || '');
}

function nextMemberId_(sh) {
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return 'ZF-001';
  const values = sh.getRange(2,2,lastRow-1,1).getValues().flat();
  let max = 0;
  values.forEach(v => {
    const m = String(v).match(/^ZF-(\d+)$/);
    if (m) max = Math.max(max, Number(m[1]));
  });
  return 'ZF-' + String(max+1).padStart(3,'0');
}

function safeName_(s) {
  return String(s||'Member').replace(/[\\/:*?"<>|#%{}]/g,' ').replace(/\s+/g,' ').trim().slice(0,80);
}
